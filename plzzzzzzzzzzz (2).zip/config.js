module.exports={ 
    db_url:[{user: 'sa'},
    {password: 'p@ssw0rd!'},
    {server: 'localhost'},
    {database: 'mysite1'},
    {maxActive:100}],
    server_port:3000,
    route_info: [
	    {file:'./user', path:'/process/login', method:'login', type:'post'}					// user.login 
    ]}

    //Json 데이터는 오브젝트(Parsing하면)
    //괄호안에서도 이름 줄 수 있음 