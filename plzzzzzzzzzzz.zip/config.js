module.exports={
    db_url:[{user: 'sa'},
    {password: 'p@ssw0rd!'},
    {server: 'localhost'},
    {database: 'mysite1'}],
    route_info: [
	    {file:'./user', path:'/process/login', method:'login', type:'post'}					// user.login 
	    ,{file:'./user', path:'/process/adduser', method:'adduser', type:'post'}				// user.adduser 
	    ,{file:'./user', path:'/process/listuser', method:'listuser', type:'post'}			// user.listuser 
    ]}